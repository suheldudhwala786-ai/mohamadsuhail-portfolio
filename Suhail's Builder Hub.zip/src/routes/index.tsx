import { createFileRoute } from "@tanstack/react-router";
import {
  motion,
  useScroll,
  useSpring,
  useTransform,
  useMotionValue,
  AnimatePresence,
} from "framer-motion";
import { useEffect, useRef, useState } from "react";
import {
  ArrowUpRight,
  Linkedin,
  Mail,
  MapPin,
  Phone,
  Download,
  Sparkles,
  Cpu,
  Code2,
  Layers,
  Rocket,
  Zap,
  Brain,
  Terminal,
  Figma,
  GitBranch,
  Database,
  Globe,
  ChevronRight,
  ChevronDown,
  Send,
  GraduationCap,
  Award,
  BookOpen,
  Github,
  Circle,
  ExternalLink,
} from "lucide-react";
import portraitAsset from "@/assets/suhail-portrait.png.asset.json";

const portrait = portraitAsset.url;

export const Route = createFileRoute("/")({
  component: Portfolio,
});

const EMAIL = "suheldudhwala786@gmail.com";
const LINKEDIN = "https://www.linkedin.com/in/mohamadsuhaildudhwala";
const PHONE_DISPLAY = "+91 78019 31801";
const PHONE_TEL = "+917801931801";
const PHONE_WA = "917801931801";

/* ─────────────────────── AMBIENT BACKGROUND ─────────────────────── */

function AmbientBackground() {
  return (
    <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
      <div className="absolute inset-0 bg-white" />
      <div className="absolute inset-0 grid-bg opacity-[0.55]" />
      <div
        className="absolute -top-40 -left-40 h-[560px] w-[560px] rounded-full animate-aurora"
        style={{
          background:
            "radial-gradient(closest-side, rgba(52,87,255,0.22), transparent 70%)",
          filter: "blur(40px)",
        }}
      />
      <div
        className="absolute top-1/3 -right-40 h-[620px] w-[620px] rounded-full animate-aurora"
        style={{
          background:
            "radial-gradient(closest-side, rgba(138,92,255,0.20), transparent 70%)",
          filter: "blur(50px)",
          animationDelay: "-8s",
        }}
      />
      <div
        className="absolute bottom-[-200px] left-1/3 h-[520px] w-[520px] rounded-full animate-aurora"
        style={{
          background:
            "radial-gradient(closest-side, rgba(34,211,238,0.18), transparent 70%)",
          filter: "blur(50px)",
          animationDelay: "-14s",
        }}
      />
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse at 50% 0%, transparent 40%, rgba(255,255,255,0.75) 90%)",
        }}
      />
    </div>
  );
}

function CursorSpotlight() {
  const x = useMotionValue(-500);
  const y = useMotionValue(-500);
  useEffect(() => {
    const onMove = (e: MouseEvent) => {
      x.set(e.clientX);
      y.set(e.clientY);
    };
    window.addEventListener("pointermove", onMove);
    return () => window.removeEventListener("pointermove", onMove);
  }, [x, y]);
  return (
    <motion.div
      aria-hidden
      className="pointer-events-none fixed inset-0 -z-[5] hidden md:block"
      style={{
        background: useTransform(
          [x, y] as never,
          ([lx, ly]: number[]) =>
            `radial-gradient(340px circle at ${lx}px ${ly}px, rgba(52,87,255,0.10), transparent 60%)`,
        ),
      }}
    />
  );
}

/* ─────────────────────── NAV ─────────────────────── */

const NAV = [
  { label: "About", href: "#about" },
  { label: "Projects", href: "#work" },
  { label: "Stack", href: "#stack" },
  { label: "Journey", href: "#journey" },
  { label: "Contact", href: "#contact" },
];

function Nav() {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return (
    <motion.header
      initial={{ y: -30, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.7, ease: [0.2, 0.7, 0.2, 1] }}
      className="fixed inset-x-0 top-0 z-50 flex justify-center px-4 pt-4"
    >
      <nav
        className={`flex items-center gap-1 rounded-full px-2 py-2 transition-all ${
          scrolled ? "glass-strong" : "glass"
        }`}
      >
        <a
          href="#top"
          className="flex items-center gap-2 px-3 py-1.5 text-sm font-medium"
        >
          <span
            className="inline-block h-2 w-2 rounded-full animate-pulse-dot"
            style={{ background: "var(--royal)" }}
          />
          <span className="hidden sm:inline">Suhail</span>
        </a>
        <div className="hidden md:flex items-center">
          {NAV.map((i) => (
            <a
              key={i.href}
              href={i.href}
              className="btn-ghost !py-1.5 !px-3 text-sm"
            >
              {i.label}
            </a>
          ))}
        </div>
        <a
          href={`mailto:${EMAIL}`}
          className="btn-primary !py-2 !px-4 text-xs ml-1"
        >
          Get in touch
          <ArrowUpRight className="h-3.5 w-3.5" />
        </a>
      </nav>
    </motion.header>
  );
}

/* ─────────────────────── HERO ─────────────────────── */

function Hero() {
  const wrapRef = useRef<HTMLDivElement>(null);
  const rx = useMotionValue(0);
  const ry = useMotionValue(0);
  const srx = useSpring(rx, { stiffness: 120, damping: 15 });
  const sry = useSpring(ry, { stiffness: 120, damping: 15 });

  const onMove = (e: React.MouseEvent) => {
    if (!wrapRef.current) return;
    const r = wrapRef.current.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width;
    const py = (e.clientY - r.top) / r.height;
    ry.set((px - 0.5) * 14);
    rx.set(-(py - 0.5) * 14);
  };
  const reset = () => {
    rx.set(0);
    ry.set(0);
  };

  return (
    <section id="top" className="container-page relative pt-32 pb-24 md:pt-40 md:pb-32">
      <div className="grid gap-14 md:grid-cols-[1.15fr_1fr] md:gap-10 items-center">
        {/* LEFT */}
        <div className="relative">
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="chip mb-6"
          >
            <span
              className="inline-block h-1.5 w-1.5 rounded-full animate-pulse-dot"
              style={{ background: "#16a34a" }}
            />
            Open to internships · Semester 3 · Vadodara, IN
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, ease: [0.2, 0.7, 0.2, 1] }}
            className="font-display text-[clamp(2.6rem,6.8vw,5.6rem)] leading-[0.98] tracking-[-0.045em]"
          >
            <span className="text-gradient">Engineering</span>
            <br />
            <span className="text-gradient-accent">intelligent software</span>
            <br />
            <span className="text-gradient">for real businesses.</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.15 }}
            className="mt-7 max-w-xl text-base md:text-lg text-[color:var(--muted-foreground)] leading-relaxed"
          >
            I&rsquo;m <b className="text-[color:var(--foreground)] font-medium">Mohamad Suhail Dudhwala</b> — a
            Software Engineering student building practical products,
            automation systems and AI-powered applications while sharpening my
            computer-science foundations.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="mt-8 flex flex-wrap items-center gap-3"
          >
            <a href="#work" className="btn-primary">
              Explore projects
              <ArrowUpRight className="h-4 w-4" />
            </a>
            <a href={`mailto:${EMAIL}`} className="btn-secondary">
              <Send className="h-4 w-4" />
              Let&rsquo;s connect
            </a>
            <a href={LINKEDIN} target="_blank" rel="noreferrer" className="btn-ghost">
              <Linkedin className="h-4 w-4" />
              LinkedIn
            </a>
          </motion.div>

          {/* meta strip */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6, duration: 0.8 }}
            className="mt-12 grid grid-cols-3 gap-4 max-w-lg"
          >
            {[
              { k: "Focus", v: "AI + Full-Stack" },
              { k: "Building", v: "GrowthStack OS" },
              { k: "Learning", v: "DSA · Java · R" },
            ].map((m) => (
              <div key={m.k} className="rounded-2xl glass p-4">
                <div className="text-[10px] uppercase tracking-widest text-[color:var(--muted-foreground)]">
                  {m.k}
                </div>
                <div className="mt-1 text-sm font-medium">{m.v}</div>
              </div>
            ))}
          </motion.div>
        </div>

        {/* RIGHT — portrait card */}
        <div
          ref={wrapRef}
          onMouseMove={onMove}
          onMouseLeave={reset}
          className="relative mx-auto w-full max-w-[420px]"
          style={{ perspective: 1400 }}
        >
          {/* Rotating rings */}
          <div className="pointer-events-none absolute inset-0 -m-8 flex items-center justify-center">
            <div
              className="absolute h-[110%] w-[110%] rounded-full border animate-spin-slow"
              style={{ borderColor: "rgba(52,87,255,0.14)" }}
            />
            <div
              className="absolute h-[125%] w-[125%] rounded-full border animate-spin-rev"
              style={{ borderColor: "rgba(138,92,255,0.12)" }}
            />
            <div
              className="absolute h-[140%] w-[140%] rounded-full border animate-spin-slow"
              style={{
                borderColor: "rgba(34,211,238,0.10)",
                animationDuration: "80s",
              }}
            />
          </div>

          <motion.div
            style={{ rotateX: srx, rotateY: sry, transformStyle: "preserve-3d" }}
            className="relative rounded-[32px] glass-strong ring-glow overflow-hidden"
          >
            <div className="relative aspect-[4/5] overflow-hidden rounded-[28px] m-3">
              <img
                src={portrait}
                alt="Portrait of Mohamad Suhail Dudhwala"
                className="h-full w-full object-cover"
                style={{ filter: "contrast(1.02) saturate(1.02)" }}
              />
              <div
                className="absolute inset-0"
                style={{
                  background:
                    "linear-gradient(180deg, transparent 55%, rgba(255,255,255,0.55) 100%)",
                }}
              />
            </div>

            {/* Floating chips */}
            <motion.div
              animate={{ y: [0, -8, 0] }}
              transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
              className="absolute -left-4 top-16 chip !bg-white/90 shadow-lg"
              style={{ transform: "translateZ(60px)" }}
            >
              <Brain className="h-3.5 w-3.5" style={{ color: "var(--royal)" }} />
              AI Builder
            </motion.div>
            <motion.div
              animate={{ y: [0, 10, 0] }}
              transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
              className="absolute -right-3 top-40 chip !bg-white/90 shadow-lg"
              style={{ transform: "translateZ(60px)" }}
            >
              <Code2 className="h-3.5 w-3.5" style={{ color: "var(--violet)" }} />
              Full-Stack
            </motion.div>
            <motion.div
              animate={{ y: [0, -6, 0] }}
              transition={{ duration: 4.5, repeat: Infinity, ease: "easeInOut" }}
              className="absolute -left-2 bottom-24 chip !bg-white/90 shadow-lg"
              style={{ transform: "translateZ(60px)" }}
            >
              <Rocket className="h-3.5 w-3.5" style={{ color: "var(--cyan)" }} />
              GrowthStack OS
            </motion.div>

            {/* Bottom identity */}
            <div className="absolute bottom-5 left-5 right-5 flex items-center justify-between rounded-2xl glass px-4 py-3">
              <div>
                <div className="text-[11px] uppercase tracking-widest text-[color:var(--muted-foreground)]">
                  Software Engineering Student
                </div>
                <div className="text-sm font-medium">ITM (SLS) Baroda University</div>
              </div>
              <GraduationCap className="h-5 w-5" style={{ color: "var(--royal)" }} />
            </div>
          </motion.div>
        </div>
      </div>

      <div className="mt-16 flex justify-center">
        <a href="#about" className="btn-ghost text-xs">
          <ChevronDown className="h-3.5 w-3.5" /> Scroll to explore
        </a>
      </div>
    </section>
  );
}

/* ─────────────────────── MARQUEE ─────────────────────── */

const MARQUEE = [
  "Java", "Python", "JavaScript", "C", "HTML", "CSS",
  "React", "Node.js", "Git", "GitHub", "Figma",
  "Prompt Engineering", "Automation", "DSA", "OOP", "AI",
];

function Marquee() {
  return (
    <section className="relative py-10 border-y border-[color:var(--border)] bg-[color:var(--surface)]/60">
      <div className="overflow-hidden">
        <div className="flex gap-10 whitespace-nowrap animate-marquee">
          {[...MARQUEE, ...MARQUEE].map((t, i) => (
            <span
              key={i}
              className="text-xl md:text-2xl font-display tracking-tight text-[color:var(--muted-foreground)]"
            >
              {t} <span className="opacity-30 mx-2">✦</span>
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─────────────────────── ABOUT ─────────────────────── */

const FOCUS = [
  { icon: Brain, title: "AI & Prompt Engineering", body: "Designing AI workflows and prompt systems that produce reliable, business-usable output." },
  { icon: Code2, title: "Full-Stack Web", body: "Building modern web apps end-to-end — from clean interfaces to server logic." },
  { icon: Cpu, title: "CS Foundations", body: "Committed to DSA, OOP, and system fundamentals — engineering, not just coding." },
  { icon: Zap, title: "Automation", body: "Turning repetitive workflows into simple, reliable, always-on systems." },
];

function About() {
  return (
    <section id="about" className="container-page relative py-28 md:py-36">
      <SectionHeader
        eyebrow="About"
        title="Building software the way real engineers do."
        subtitle="I care about products people actually use — clarity, taste, and correctness."
      />

      <div className="mt-14 grid gap-6 md:grid-cols-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.7 }}
          className="md:col-span-7 card-soft p-8 md:p-10 relative overflow-hidden"
        >
          <div
            className="absolute -top-24 -right-24 h-64 w-64 rounded-full opacity-70"
            style={{
              background:
                "radial-gradient(closest-side, rgba(52,87,255,0.18), transparent 70%)",
              filter: "blur(30px)",
            }}
          />
          <p className="text-lg md:text-xl leading-relaxed">
            I&rsquo;m currently in <b>Semester 3</b> of a Diploma in Information
            Technology at <b>ITM (SLS) Baroda University</b>. My focus is
            simple: <span className="text-gradient-accent font-medium">learn deeply, build honestly, ship consistently.</span>
          </p>
          <p className="mt-4 text-[color:var(--muted-foreground)] leading-relaxed">
            Alongside coursework, I build real projects — <b>GrowthStack OS</b>,
            <b> TradePulse</b>, and <b>FinPulse AI</b> — that combine
            AI, automation, and full-stack development. Everything here is
            in active development. No fabricated metrics, no fake case studies.
          </p>

          <div className="mt-8 grid grid-cols-2 sm:grid-cols-3 gap-3">
            {[
              { k: "Location", v: "Vadodara, IN" },
              { k: "Status", v: "Student · Builder" },
              { k: "Availability", v: "Internships" },
            ].map((m) => (
              <div key={m.k} className="rounded-2xl border border-[color:var(--border)] p-4 bg-white">
                <div className="text-[10px] uppercase tracking-widest text-[color:var(--muted-foreground)]">{m.k}</div>
                <div className="text-sm font-medium mt-1">{m.v}</div>
              </div>
            ))}
          </div>
        </motion.div>

        <div className="md:col-span-5 grid gap-4">
          {FOCUS.map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.6, delay: i * 0.05 }}
              className="card-soft p-5 flex gap-4 items-start hover:-translate-y-0.5 transition-transform"
            >
              <div
                className="h-10 w-10 rounded-xl flex items-center justify-center shrink-0"
                style={{
                  background:
                    "linear-gradient(135deg, rgba(52,87,255,0.12), rgba(138,92,255,0.12))",
                }}
              >
                <f.icon className="h-5 w-5" style={{ color: "var(--royal)" }} />
              </div>
              <div>
                <div className="font-medium">{f.title}</div>
                <p className="text-sm text-[color:var(--muted-foreground)] mt-1 leading-relaxed">
                  {f.body}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─────────────────────── EDUCATION ─────────────────────── */

function Education() {
  const items = [
    {
      period: "Jul 2025 – Present",
      title: "Diploma in Information Technology",
      org: "ITM (SLS) Baroda University",
      body: "Currently in Semester 3 · Studying DSA, OOP (Java), Computer Organization & Architecture, Statistics with R, and System Programming.",
      icon: GraduationCap,
    },
    {
      period: "2025",
      title: "SSC — GSEB",
      org: "Secondary School Certificate",
      body: "Scored 79% · 83 Percentile · Built the foundation to move into computer science.",
      icon: BookOpen,
    },
  ];
  return (
    <section id="education" className="container-page py-24 md:py-32">
      <SectionHeader eyebrow="Education" title="Academic journey." />
      <div className="mt-12 grid gap-4 md:grid-cols-2">
        {items.map((it, i) => (
          <motion.div
            key={it.title}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.6, delay: i * 0.05 }}
            className="card-soft p-7 relative overflow-hidden"
          >
            <div className="flex items-center gap-3">
              <div
                className="h-10 w-10 rounded-xl flex items-center justify-center"
                style={{
                  background:
                    "linear-gradient(135deg, rgba(52,87,255,0.12), rgba(34,211,238,0.12))",
                }}
              >
                <it.icon className="h-5 w-5" style={{ color: "var(--royal)" }} />
              </div>
              <span className="text-[11px] uppercase tracking-widest text-[color:var(--muted-foreground)]">
                {it.period}
              </span>
            </div>
            <div className="mt-4 text-lg font-medium">{it.title}</div>
            <div className="text-sm text-[color:var(--muted-foreground)]">{it.org}</div>
            <p className="mt-3 text-sm leading-relaxed text-[color:var(--muted-foreground)]">
              {it.body}
            </p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

/* ─────────────────────── PROJECTS ─────────────────────── */

const PROJECTS = [
  {
    name: "GrowthStack OS",
    tagline: "An AI operating system for growing businesses.",
    problem:
      "Small and mid-size businesses juggle a dozen disconnected tools — marketing, ops, analytics — without a single AI-native workspace.",
    solution:
      "A unified web platform with AI copilots, dashboards, and automations that behave like an in-house growth team.",
    contribution:
      "Product design, frontend engineering, prompt/AI workflow design, and end-to-end integration.",
    tech: ["React", "TypeScript", "Tailwind", "AI Workflows", "Automation"],
    status: "In Active Development",
    roadmap: "Deeper analytics, workflow builder, multi-tenant workspace, integrations.",
    accent: "from-[#3457ff] to-[#8a5cff]",
    live: "https://growthstack-ai.base44.app/",
  },
  {
    name: "TradePulse",
    tagline: "Market intelligence, made readable.",
    problem:
      "Retail traders drown in noisy feeds and screens that speak in jargon, not decisions.",
    solution:
      "A calm, focused interface that surfaces the signals that matter and explains them in plain language.",
    contribution:
      "Interface design, information architecture, and frontend implementation.",
    tech: ["React", "TypeScript", "Data Viz", "AI Summarisation"],
    status: "In Active Development",
    roadmap: "Alerting, watchlists, richer market context, mobile experience.",
    accent: "from-[#0ea5e9] to-[#22d3ee]",
    live: "https://the-tradepulse.base44.app/",
  },
  {
    name: "FinPulse AI",
    tagline: "A calmer relationship with personal finance.",
    problem:
      "Most finance apps show numbers. Few help people actually understand and act on them.",
    solution:
      "An AI-powered assistant that reads your finances, explains patterns, and suggests small, doable next steps.",
    contribution:
      "Concept, product design, and full-stack prototype.",
    tech: ["React", "TypeScript", "AI", "Node.js"],
    status: "In Active Development",
    roadmap: "Bank integrations, goals, coaching flows, privacy hardening.",
    accent: "from-[#8a5cff] to-[#ec4899]",
    live: null,
  },
];

function Work() {
  return (
    <section id="work" className="container-page py-28 md:py-36">
      <SectionHeader
        eyebrow="Selected Work"
        title="Real projects. Honest status."
        subtitle="Products I&rsquo;m actively designing, building, and iterating on — no fabricated metrics."
      />

      <div className="mt-14 flex flex-col gap-10">
        {PROJECTS.map((p, i) => (
          <motion.article
            key={p.name}
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.8, ease: [0.2, 0.7, 0.2, 1] }}
            className="relative card-soft overflow-hidden"
          >
            <div className="grid md:grid-cols-[1.05fr_1fr]">
              {/* Visual */}
              <div className="relative min-h-[280px] md:min-h-[420px] overflow-hidden">
                <div className={`absolute inset-0 bg-gradient-to-br ${p.accent} opacity-90`} />
                <div className="absolute inset-0 grid-bg opacity-20 mix-blend-overlay" />
                <div className="absolute inset-0 flex items-center justify-center p-10">
                  <div className="relative w-full max-w-sm">
                    <div className="absolute -inset-6 rounded-3xl bg-white/25 blur-2xl" />
                    <div className="relative rounded-3xl bg-white/85 backdrop-blur-xl border border-white/70 p-6 shadow-2xl">
                      <div className="flex items-center gap-2 text-[10px] uppercase tracking-widest text-[color:var(--muted-foreground)]">
                        <Circle className="h-2 w-2 fill-current" />
                        {p.status}
                      </div>
                      <div className="mt-3 text-2xl font-display tracking-tight">
                        {p.name}
                      </div>
                      <div className="mt-1 text-sm text-[color:var(--muted-foreground)]">
                        {p.tagline}
                      </div>
                      <div className="mt-5 flex flex-wrap gap-1.5">
                        {p.tech.slice(0, 4).map((t) => (
                          <span key={t} className="chip !py-1 !px-2 !text-[10px]">
                            {t}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
                <div className="absolute top-5 left-5 text-white/85 text-xs font-mono">
                  0{i + 1} / 0{PROJECTS.length}
                </div>
              </div>

              {/* Content */}
              <div className="p-8 md:p-10">
                <h3 className="text-2xl md:text-3xl font-display tracking-tight">
                  {p.name}
                </h3>

                <Detail label="Problem" body={p.problem} />
                <Detail label="Solution" body={p.solution} />
                <Detail label="My contribution" body={p.contribution} />
                <Detail label="Status" body={p.status} />
                <Detail label="Roadmap" body={p.roadmap} />

                <div className="mt-6 flex flex-wrap gap-2">
                  {p.tech.map((t) => (
                    <span key={t} className="chip">{t}</span>
                  ))}
                </div>

                {p.live && (
                  <div className="mt-6">
                    <a
                      href={p.live}
                      target="_blank"
                      rel="noreferrer"
                      className="btn-primary"
                    >
                      Visit live
                      <ExternalLink className="h-3.5 w-3.5" />
                    </a>
                  </div>
                )}
              </div>
            </div>
          </motion.article>
        ))}
      </div>
    </section>
  );
}

function Detail({ label, body }: { label: string; body: string }) {
  return (
    <div className="mt-5">
      <div className="text-[10px] uppercase tracking-widest text-[color:var(--muted-foreground)]">
        {label}
      </div>
      <div className="mt-1 text-sm leading-relaxed">{body}</div>
    </div>
  );
}

/* ─────────────────────── STACK / GALAXY ─────────────────────── */

const STACK = {
  Languages: ["Java", "Python", "JavaScript", "C"],
  Web: ["HTML", "CSS", "React", "Tailwind"],
  CS: ["DSA", "OOP", "Statistics (R)", "System Programming"],
  Tools: ["Git", "GitHub", "Figma", "Automation"],
  AI: ["Prompt Engineering", "AI Workflows", "LLM Apps"],
};

function Stack() {
  return (
    <section id="stack" className="container-page py-28 md:py-36">
      <SectionHeader
        eyebrow="Technology Stack"
        title="Tools I use to think and build."
        subtitle="A clear, honest inventory — the things I&rsquo;ve actually worked with and continue to learn."
      />
      <div className="mt-14 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
        {Object.entries(STACK).map(([group, items], i) => (
          <motion.div
            key={group}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.6, delay: i * 0.05 }}
            className="card-soft p-7 relative overflow-hidden group"
          >
            <div
              className="absolute -bottom-16 -right-16 h-40 w-40 rounded-full opacity-60 group-hover:opacity-100 transition"
              style={{
                background:
                  "radial-gradient(closest-side, rgba(52,87,255,0.18), transparent 70%)",
                filter: "blur(24px)",
              }}
            />
            <div className="flex items-center gap-2 text-[11px] uppercase tracking-widest text-[color:var(--muted-foreground)]">
              <Layers className="h-3.5 w-3.5" />
              {group}
            </div>
            <div className="mt-5 flex flex-wrap gap-2">
              {items.map((t) => (
                <span key={t} className="chip">{t}</span>
              ))}
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

/* ─────────────────────── CURRENTLY LEARNING ─────────────────────── */

function Learning() {
  const items = [
    { title: "Data Structures & Algorithms", icon: Cpu },
    { title: "Object-Oriented Programming (Java)", icon: Code2 },
    { title: "Computer Organization & Architecture", icon: Database },
    { title: "Statistics with R", icon: Terminal },
    { title: "System Programming", icon: GitBranch },
  ];
  return (
    <section className="container-page py-24">
      <SectionHeader eyebrow="Currently Learning" title="Semester 3, in progress." />
      <div className="mt-10 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {items.map((it, i) => (
          <motion.div
            key={it.title}
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.5, delay: i * 0.04 }}
            className="card-soft p-5 flex items-center gap-4"
          >
            <div
              className="h-10 w-10 rounded-xl flex items-center justify-center"
              style={{
                background:
                  "linear-gradient(135deg, rgba(138,92,255,0.14), rgba(34,211,238,0.14))",
              }}
            >
              <it.icon className="h-5 w-5" style={{ color: "var(--violet)" }} />
            </div>
            <div className="font-medium">{it.title}</div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

/* ─────────────────────── JOURNEY / TIMELINE ─────────────────────── */

const JOURNEY = [
  {
    year: "2025",
    title: "Completed SSC (GSEB)",
    body: "Scored 79% · 83 Percentile. Set the foundation to move into computer science.",
  },
  {
    year: "Jul 2025",
    title: "Started Diploma in IT",
    body: "Joined ITM (SLS) Baroda University to formally study Information Technology.",
  },
  {
    year: "2025 – 2026",
    title: "Semester 1 & 2",
    body: "Built foundations in C, Python, Java, HTML, CSS, JavaScript, and Web Design.",
  },
  {
    year: "2026 · Current",
    title: "Semester 3",
    body: "Learning DSA, OOP (Java), Computer Organization & Architecture, Statistics (R), and System Programming.",
  },
  {
    year: "2026",
    title: "Building GrowthStack OS",
    body: "Designing and shipping an AI-powered operating system for growing businesses.",
  },
  {
    year: "Future",
    title: "Internship · Open Source · AI Products",
    body: "Aiming for a Software Engineering internship, open-source contributions, and shipping real AI products.",
  },
];

function Journey() {
  return (
    <section id="journey" className="container-page py-28 md:py-36">
      <SectionHeader eyebrow="Timeline" title="Where I&rsquo;ve been. Where I&rsquo;m going." />
      <div className="relative mt-14">
        <div
          className="absolute left-5 md:left-1/2 top-0 bottom-0 w-px"
          style={{
            background:
              "linear-gradient(180deg, transparent, rgba(52,87,255,0.35), rgba(138,92,255,0.35), transparent)",
          }}
        />
        <div className="flex flex-col gap-10">
          {JOURNEY.map((j, i) => {
            const left = i % 2 === 0;
            return (
              <motion.div
                key={j.title}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.6 }}
                className={`relative md:grid md:grid-cols-2 md:gap-10 ${left ? "" : "md:[&>*:first-child]:col-start-2"}`}
              >
                <div className={`pl-14 md:pl-0 ${left ? "md:pr-10 md:text-right" : "md:pl-10"}`}>
                  <div className="card-soft p-6 inline-block max-w-md">
                    <div className="text-[11px] uppercase tracking-widest text-[color:var(--muted-foreground)]">
                      {j.year}
                    </div>
                    <div className="mt-1 font-display text-xl">{j.title}</div>
                    <p className="mt-2 text-sm text-[color:var(--muted-foreground)] leading-relaxed">
                      {j.body}
                    </p>
                  </div>
                </div>
                <div className="absolute left-5 md:left-1/2 top-4 -translate-x-1/2">
                  <div className="h-3 w-3 rounded-full ring-4 ring-white"
                    style={{ background: "linear-gradient(135deg, var(--royal), var(--violet))" }}
                  />
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

/* ─────────────────────── CERTIFICATIONS ─────────────────────── */

const CERTS = [
  { org: "SAP", title: "Designing Stories in SAP Analytics Cloud", tag: "Data Storytelling" },
  { org: "Google", title: "Fundamentals of Digital Marketing", tag: "Marketing" },
  { org: "Figma", title: "Figma Essentials", tag: "Design" },
  { org: "ITM", title: "ITM Collaboration Certificate", tag: "Collaboration" },
  { org: "Future", title: "More certifications in progress", tag: "Ongoing", coming: true },
];

function Certifications() {
  return (
    <section id="certifications" className="container-page py-24 md:py-32">
      <SectionHeader
        eyebrow="Certifications"
        title="Learning that leaves a trail."
      />
      <div className="mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
        {CERTS.map((c, i) => (
          <motion.div
            key={c.title}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.6, delay: i * 0.05 }}
            className="card-soft p-7 relative overflow-hidden group"
          >
            <div
              className="absolute -top-16 -right-16 h-36 w-36 rounded-full opacity-70"
              style={{
                background:
                  "radial-gradient(closest-side, rgba(138,92,255,0.18), transparent 70%)",
                filter: "blur(24px)",
              }}
            />
            <div className="flex items-center justify-between">
              <div
                className="h-10 w-10 rounded-xl flex items-center justify-center"
                style={{
                  background:
                    "linear-gradient(135deg, rgba(52,87,255,0.14), rgba(138,92,255,0.14))",
                }}
              >
                <Award className="h-5 w-5" style={{ color: "var(--royal)" }} />
              </div>
              <span className="chip !text-[10px]">{c.tag}</span>
            </div>
            <div className="mt-5 text-[11px] uppercase tracking-widest text-[color:var(--muted-foreground)]">
              {c.org}
            </div>
            <div className="mt-1 font-display text-lg leading-snug">{c.title}</div>
            {c.coming && (
              <div className="mt-3 text-xs text-[color:var(--muted-foreground)]">
                In progress
              </div>
            )}
          </motion.div>
        ))}
      </div>
    </section>
  );
}

/* ─────────────────────── LINKEDIN & GITHUB ─────────────────────── */

function SocialShowcase() {
  return (
    <section className="container-page py-24">
      <div className="grid gap-5 md:grid-cols-2">
        <motion.a
          href={LINKEDIN}
          target="_blank"
          rel="noreferrer"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="card-soft p-8 relative overflow-hidden group hover:-translate-y-1 transition-transform"
        >
          <div
            className="absolute -top-20 -right-20 h-56 w-56 rounded-full opacity-70"
            style={{
              background:
                "radial-gradient(closest-side, rgba(52,87,255,0.20), transparent 70%)",
              filter: "blur(30px)",
            }}
          />
          <Linkedin className="h-6 w-6" style={{ color: "var(--royal)" }} />
          <div className="mt-6 text-[11px] uppercase tracking-widest text-[color:var(--muted-foreground)]">
            Featured on LinkedIn
          </div>
          <div className="mt-2 font-display text-2xl">Follow my building journey</div>
          <p className="mt-3 text-sm text-[color:var(--muted-foreground)] leading-relaxed max-w-md">
            I share honest updates on what I&rsquo;m learning, what I&rsquo;m building,
            and the lessons behind each project.
          </p>
          <div className="mt-6 inline-flex items-center gap-1.5 text-sm font-medium">
            Visit profile <ArrowUpRight className="h-4 w-4 group-hover:-translate-y-0.5 group-hover:translate-x-0.5 transition-transform" />
          </div>
        </motion.a>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.05 }}
          className="card-soft p-8 relative overflow-hidden"
        >
          <div
            className="absolute -top-20 -right-20 h-56 w-56 rounded-full opacity-70"
            style={{
              background:
                "radial-gradient(closest-side, rgba(138,92,255,0.20), transparent 70%)",
              filter: "blur(30px)",
            }}
          />
          <Github className="h-6 w-6" style={{ color: "var(--foreground)" }} />
          <div className="mt-6 text-[11px] uppercase tracking-widest text-[color:var(--muted-foreground)]">
            GitHub
          </div>
          <div className="mt-2 font-display text-2xl">Coming soon</div>
          <p className="mt-3 text-sm text-[color:var(--muted-foreground)] leading-relaxed max-w-md">
            I&rsquo;m preparing my public repositories — open-source contributions,
            project source, and small learning experiments will live here.
          </p>
          <div className="mt-6 chip">
            <Sparkles className="h-3.5 w-3.5" style={{ color: "var(--violet)" }} />
            Setting up · 2026
          </div>
        </motion.div>
      </div>
    </section>
  );
}

/* ─────────────────────── FAQ ─────────────────────── */

const FAQ = [
  {
    q: "Are you available for internships right now?",
    a: "Yes — I&rsquo;m open to Software Engineering, AI, and Full-Stack internships. Remote or based out of Vadodara, India.",
  },
  {
    q: "What are you strongest at today?",
    a: "Building modern web applications, working with AI/LLM workflows, and turning fuzzy problems into shippable prototypes.",
  },
  {
    q: "What are you deliberately improving?",
    a: "Data Structures & Algorithms, deeper OOP with Java, and computer-science fundamentals — I want to think like an engineer, not just code like one.",
  },
  {
    q: "Are the metrics on your projects real?",
    a: "There are none. Every project is honestly labelled as \"In Active Development\" — I don&rsquo;t fabricate users, revenue, or performance numbers.",
  },
  {
    q: "How can we work together?",
    a: "Email is the fastest way — I reply personally, usually within a day.",
  },
];

function Faq() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <section id="faq" className="container-page py-24 md:py-32">
      <SectionHeader eyebrow="FAQ" title="Straight answers." />
      <div className="mt-10 max-w-3xl mx-auto flex flex-col gap-3">
        {FAQ.map((f, i) => {
          const isOpen = open === i;
          return (
            <motion.div
              key={f.q}
              initial={{ opacity: 0, y: 12 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.4, delay: i * 0.03 }}
              className="card-soft overflow-hidden"
            >
              <button
                onClick={() => setOpen(isOpen ? null : i)}
                className="w-full flex items-center justify-between gap-4 p-5 text-left"
              >
                <span className="font-medium">{f.q}</span>
                <ChevronRight
                  className={`h-4 w-4 transition-transform ${isOpen ? "rotate-90" : ""}`}
                  style={{ color: "var(--muted-foreground)" }}
                />
              </button>
              <AnimatePresence initial={false}>
                {isOpen && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <div
                      className="px-5 pb-5 text-sm text-[color:var(--muted-foreground)] leading-relaxed"
                      dangerouslySetInnerHTML={{ __html: f.a }}
                    />
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          );
        })}
      </div>
    </section>
  );
}

/* ─────────────────────── CONTACT ─────────────────────── */

function Contact() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const mailto = `mailto:${EMAIL}?subject=${encodeURIComponent(
    `Hello from ${name || "your site"}`,
  )}&body=${encodeURIComponent(`${message}\n\n— ${name} (${email})`)}`;
  return (
    <section id="contact" className="container-page py-28 md:py-36">
      <div className="relative rounded-[32px] glass-strong overflow-hidden p-8 md:p-14">
        <div
          className="absolute -top-32 -left-32 h-[420px] w-[420px] rounded-full opacity-80"
          style={{
            background:
              "radial-gradient(closest-side, rgba(52,87,255,0.22), transparent 70%)",
            filter: "blur(40px)",
          }}
        />
        <div
          className="absolute -bottom-32 -right-32 h-[420px] w-[420px] rounded-full opacity-80"
          style={{
            background:
              "radial-gradient(closest-side, rgba(138,92,255,0.22), transparent 70%)",
            filter: "blur(40px)",
          }}
        />
        <div className="relative grid gap-10 md:grid-cols-[1fr_1.05fr]">
          <div>
            <div className="chip">
              <span
                className="inline-block h-1.5 w-1.5 rounded-full animate-pulse-dot"
                style={{ background: "#16a34a" }}
              />
              Open to internships
            </div>
            <h2 className="mt-5 font-display text-4xl md:text-5xl tracking-[-0.03em] leading-[1.05]">
              Let&rsquo;s build something<br />
              <span className="text-gradient-accent">worth shipping.</span>
            </h2>
            <p className="mt-5 text-[color:var(--muted-foreground)] max-w-md leading-relaxed">
              I&rsquo;m open to Software Engineering internships, AI projects,
              full-stack collaborations, and research work. The fastest way to
              reach me is email — I reply personally.
            </p>
            <div className="mt-8 grid gap-3 max-w-md">
              <a href={`mailto:${EMAIL}`} className="card-soft p-4 flex items-center gap-3 hover:-translate-y-0.5 transition-transform">
                <Mail className="h-5 w-5" style={{ color: "var(--royal)" }} />
                <div>
                  <div className="text-[10px] uppercase tracking-widest text-[color:var(--muted-foreground)]">Email</div>
                  <div className="text-sm font-medium">{EMAIL}</div>
                </div>
              </a>
              <a href={LINKEDIN} target="_blank" rel="noreferrer" className="card-soft p-4 flex items-center gap-3 hover:-translate-y-0.5 transition-transform">
                <Linkedin className="h-5 w-5" style={{ color: "var(--royal)" }} />
                <div>
                  <div className="text-[10px] uppercase tracking-widest text-[color:var(--muted-foreground)]">LinkedIn</div>
                  <div className="text-sm font-medium">/in/mohamadsuhaildudhwala</div>
                </div>
              </a>
              <a href={`tel:${PHONE_TEL}`} className="card-soft p-4 flex items-center gap-3 hover:-translate-y-0.5 transition-transform">
                <Phone className="h-5 w-5" style={{ color: "var(--royal)" }} />
                <div>
                  <div className="text-[10px] uppercase tracking-widest text-[color:var(--muted-foreground)]">Phone</div>
                  <div className="text-sm font-medium">{PHONE_DISPLAY}</div>
                </div>
              </a>
              <a href={`https://wa.me/${PHONE_WA}`} target="_blank" rel="noreferrer" className="card-soft p-4 flex items-center gap-3 hover:-translate-y-0.5 transition-transform">
                <Send className="h-5 w-5" style={{ color: "#22c55e" }} />
                <div>
                  <div className="text-[10px] uppercase tracking-widest text-[color:var(--muted-foreground)]">WhatsApp</div>
                  <div className="text-sm font-medium">Message me on WhatsApp</div>
                </div>
              </a>
              <div className="card-soft p-4 flex items-center gap-3">
                <MapPin className="h-5 w-5" style={{ color: "var(--violet)" }} />
                <div>
                  <div className="text-[10px] uppercase tracking-widest text-[color:var(--muted-foreground)]">Location</div>
                  <div className="text-sm font-medium">Vadodara, Gujarat · India</div>
                </div>
              </div>
            </div>
          </div>


          <form
            onSubmit={(e) => {
              e.preventDefault();
              window.location.href = mailto;
            }}
            className="rounded-[24px] bg-white/80 border border-white p-6 md:p-8 shadow-xl backdrop-blur-xl flex flex-col gap-4"
          >
            <Field label="Your name">
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                className="w-full bg-transparent outline-none py-2 text-sm"
                placeholder="Ada Lovelace"
              />
            </Field>
            <Field label="Email">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="w-full bg-transparent outline-none py-2 text-sm"
                placeholder="you@company.com"
              />
            </Field>
            <Field label="Message">
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                required
                rows={5}
                className="w-full bg-transparent outline-none py-2 text-sm resize-none"
                placeholder="Tell me about the role, project, or idea…"
              />
            </Field>
            <button type="submit" className="btn-primary justify-center mt-1">
              <Send className="h-4 w-4" /> Send message
            </button>
            <p className="text-[11px] text-[color:var(--muted-foreground)] text-center">
              Opens your email client · goes straight to my inbox.
            </p>
          </form>
        </div>
      </div>
    </section>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block rounded-2xl border border-[color:var(--border)] bg-white px-4 py-2 focus-within:border-[color:var(--border-strong)] transition">
      <div className="text-[10px] uppercase tracking-widest text-[color:var(--muted-foreground)]">
        {label}
      </div>
      {children}
    </label>
  );
}

/* ─────────────────────── FOOTER ─────────────────────── */

function Footer() {
  return (
    <footer className="container-page pb-14 pt-10">
      <div className="border-t border-[color:var(--border)] pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="text-sm text-[color:var(--muted-foreground)]">
          © {new Date().getFullYear()} Mohamad Suhail Dudhwala · Vadodara, India
        </div>
        <div className="flex items-center gap-3 text-sm">
          <a href={`mailto:${EMAIL}`} className="btn-ghost">Email</a>
          <a href={LINKEDIN} target="_blank" rel="noreferrer" className="btn-ghost">LinkedIn</a>
          <a href="#top" className="btn-secondary">
            Back to top <ArrowUpRight className="h-3.5 w-3.5" />
          </a>
        </div>
      </div>
    </footer>
  );
}

/* ─────────────────────── SECTION HEADER ─────────────────────── */

function SectionHeader({
  eyebrow,
  title,
  subtitle,
}: {
  eyebrow: string;
  title: string;
  subtitle?: string;
}) {
  return (
    <div className="max-w-3xl">
      <div className="chip">
        <Sparkles className="h-3.5 w-3.5" style={{ color: "var(--royal)" }} />
        {eyebrow}
      </div>
      <h2
        className="mt-5 font-display text-4xl md:text-5xl lg:text-6xl tracking-[-0.035em] leading-[1.02]"
        dangerouslySetInnerHTML={{ __html: title }}
      />
      {subtitle && (
        <p
          className="mt-4 text-[color:var(--muted-foreground)] text-base md:text-lg max-w-2xl leading-relaxed"
          dangerouslySetInnerHTML={{ __html: subtitle }}
        />
      )}
    </div>
  );
}

/* ─────────────────────── PROGRESS BAR ─────────────────────── */

function ScrollProgress() {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, { stiffness: 120, damping: 20 });
  return (
    <motion.div
      style={{ scaleX, transformOrigin: "0%" }}
      className="fixed top-0 left-0 right-0 h-[2px] z-[60]"
    >
      <div
        className="h-full w-full"
        style={{
          background:
            "linear-gradient(90deg, var(--royal), var(--violet), var(--cyan))",
        }}
      />
    </motion.div>
  );
}

/* ─────────────────────── PAGE ─────────────────────── */

function Portfolio() {
  return (
    <div className="relative min-h-screen">
      <AmbientBackground />
      <CursorSpotlight />
      <ScrollProgress />
      <Nav />
      <main>
        <Hero />
        <Marquee />
        <About />
        <Education />
        <Work />
        <Stack />
        <Learning />
        <Journey />
        <Certifications />
        <SocialShowcase />
        <Faq />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
